import argparse
import sys
import os
from gcp_dag_validator.core.rule_engine import evaluate_file

# ANSI Colors for terminal output
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"
BOLD = "\033[1m"

def main():
    parser = argparse.ArgumentParser(description="GCP DAG Compliance Validator")
    parser.add_argument("filenames", nargs="*", help="Files to validate")
    args = parser.parse_args()

    if not args.filenames:
        return 0

    total_violations = 0

    for filename in args.filenames:
        if not os.path.exists(filename):
            continue

        try:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            print(f"{YELLOW}[WARN]{RESET} Could not read {filename}: {e}")
            continue

        # Ignore massive data dumps locally as well
        if len(content.encode('utf-8')) > 500 * 1024:
            print(f"{YELLOW}[SKIP]{RESET} {filename} (File > 500KB)")
            continue

        violations = evaluate_file(filename, content)
        
        # Filter out passes, we only want to fail the commit if there are errors
        real_violations = [v for v in violations if v['status'] == 'FAIL']

        if real_violations:
            print(f"\n{RED}{BOLD}FAIL:{RESET} {BOLD}{filename}{RESET}")
            for v in real_violations:
                print(f"  {RED}Line {v['line_number']}:{RESET} [{v['rule_id']}] {v['rule_name']}")
                print(f"    Snippet: {v['code_snippet'].strip()[:150]}")
            total_violations += len(real_violations)

    if total_violations > 0:
        print(f"\n{RED}{BOLD}Pre-commit failed! Found {total_violations} compliance violation(s).{RESET}")
        sys.exit(1)
    
    sys.exit(0)

if __name__ == "__main__":
    main()