from airflow import DAG
from airflow.models import Variable
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import PythonOperator
from datetime import datetime


def _execute_compliant_task(**kwargs):
    # Runtime resolution keeps the DAG scheduler lightweight and DR-friendly.
    db_config = Variable.get("global_db_config")
    project_id = Variable.get("gcp_project_id")
    region = Variable.get("gcp_region")
    dataset = Variable.get("bq_dataset")
    table = Variable.get("bq_table")
    gcs_bucket = Variable.get("billing_output_bucket")
    output_prefix = Variable.get("billing_output_prefix")

    output_path = f"gs://{gcs_bucket}/{output_prefix}"
    query = f"SELECT * FROM `{project_id}.{dataset}.{table}`"

    print(f"Running task in {region} for project {project_id}")
    print(f"Output path: {output_path}")
    print(f"Query: {query}")
    print(f"Loaded db config length: {len(db_config)}")

default_args = {'owner': 'data-eng', 'start_date': datetime(2026, 1, 1)}

with DAG('compliant_dr_dag', default_args=default_args, schedule_interval='@daily') as dag:
    start_task = EmptyOperator(task_id='start') 
    
    process_task = PythonOperator(
        task_id='process_data',
        python_callable=_execute_compliant_task
    )
    
    start_task >> process_task